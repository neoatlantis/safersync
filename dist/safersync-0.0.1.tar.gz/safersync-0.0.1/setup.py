from distutils.core import setup

setup(
    name='safersync',
    version='0.0.1',
    author='NeoAtlantis',
    author_email='aurichalka@gmail.com',
    packages=['safersync']
)

