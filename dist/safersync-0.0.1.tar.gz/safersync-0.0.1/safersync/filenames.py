#!/usr/bin/env python3

COMMON_PREFIX = ".srsync-"

SRC_MARKER_FILE = COMMON_PREFIX + "src"
DST_MARKER_FILE = COMMON_PREFIX + "dst"
DST_LOCK_FILE = COMMON_PREFIX + "lockfile"
